import 'package:flutter/material.dart';
import 'package:tsmc/BLE/ble_setup.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();  // Add this line
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Scaffold(
        body: Center(
          child: BleSetup(),
        ),
      ),
    );
  }
}