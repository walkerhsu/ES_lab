/// print message in development environment
void mprint(dynamic message){
  bool development = true;
  if(development){
    print(message);
  }
}
